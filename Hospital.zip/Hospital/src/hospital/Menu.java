package hospital;

import hospital.model.*;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Menu extends javax.swing.JFrame {

    private final Util util = new Util();
    private final Patient pt = new Patient();
    private final Doctor dt = new Doctor();
    private final Nurse ns = new Nurse();
    private final Room rm = new Room();
    private final Service sc = new Service();
    private final Invoice iv = new Invoice();
    private final Familiar fm = new Familiar();
    private final Consult cl = new Consult();
    private final Internship is = new Internship();

    public Menu() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        container = new javax.swing.JPanel();
        panelPatient = new javax.swing.JPanel();
        patBtn = new javax.swing.JButton();
        addPatBtn = new javax.swing.JButton();
        deletePatBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        panelDoctor = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        docsBtn = new javax.swing.JButton();
        addDocBtn = new javax.swing.JButton();
        removeDocBtn = new javax.swing.JButton();
        panelNurse = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        nursBtn = new javax.swing.JButton();
        addNurBtn = new javax.swing.JButton();
        removeNurBtn = new javax.swing.JButton();
        panelRoom = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        roomsBtn = new javax.swing.JButton();
        addRoomBtn = new javax.swing.JButton();
        removeRoomBtn = new javax.swing.JButton();
        panelService = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        servBtn = new javax.swing.JButton();
        addServBtn = new javax.swing.JButton();
        removeServBtn = new javax.swing.JButton();
        panelConsult = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        nursBtn1 = new javax.swing.JButton();
        invoiceBtn = new javax.swing.JButton();
        historyInternshipBtn = new javax.swing.JButton();
        panelOthers2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        consultBtn2 = new javax.swing.JButton();
        addConsultBtn4 = new javax.swing.JButton();
        panelOthers1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        InternshipBtn = new javax.swing.JButton();
        addInternshipBtn = new javax.swing.JButton();
        removeInternshipBtn = new javax.swing.JButton();
        exitBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1060, 566));
        setResizable(false);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Hospital Clinica San Pedro");

        container.setPreferredSize(new java.awt.Dimension(1260, 566));

        patBtn.setBackground(new java.awt.Color(51, 153, 255));
        patBtn.setForeground(new java.awt.Color(255, 255, 255));
        patBtn.setText("Ver Pacientes");
        patBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                patBtnActionPerformed(evt);
            }
        });

        addPatBtn.setBackground(new java.awt.Color(0, 153, 0));
        addPatBtn.setForeground(new java.awt.Color(255, 255, 255));
        addPatBtn.setText("Agregar Paciente");
        addPatBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addPatBtnActionPerformed(evt);
            }
        });

        deletePatBtn.setBackground(new java.awt.Color(255, 102, 102));
        deletePatBtn.setForeground(new java.awt.Color(255, 255, 255));
        deletePatBtn.setText("Borrar Paciente");
        deletePatBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletePatBtnActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Menu Pacientes");

        javax.swing.GroupLayout panelPatientLayout = new javax.swing.GroupLayout(panelPatient);
        panelPatient.setLayout(panelPatientLayout);
        panelPatientLayout.setHorizontalGroup(
            panelPatientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPatientLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(panelPatientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(patBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addPatBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(deletePatBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE))
                .addGap(30, 30, 30))
        );
        panelPatientLayout.setVerticalGroup(
            panelPatientLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPatientLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel3)
                .addGap(15, 15, 15)
                .addComponent(patBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(addPatBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(deletePatBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        panelDoctor.setPreferredSize(new java.awt.Dimension(280, 205));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Menu Doctores");

        docsBtn.setBackground(new java.awt.Color(51, 153, 255));
        docsBtn.setForeground(new java.awt.Color(255, 255, 255));
        docsBtn.setText("Ver Doctores");
        docsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                docsBtnActionPerformed(evt);
            }
        });

        addDocBtn.setBackground(new java.awt.Color(0, 153, 0));
        addDocBtn.setForeground(new java.awt.Color(255, 255, 255));
        addDocBtn.setText("Agregar Doctor");
        addDocBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDocBtnActionPerformed(evt);
            }
        });

        removeDocBtn.setBackground(new java.awt.Color(255, 102, 102));
        removeDocBtn.setForeground(new java.awt.Color(255, 255, 255));
        removeDocBtn.setText("Borrar Doctor");
        removeDocBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeDocBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelDoctorLayout = new javax.swing.GroupLayout(panelDoctor);
        panelDoctor.setLayout(panelDoctorLayout);
        panelDoctorLayout.setHorizontalGroup(
            panelDoctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDoctorLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(panelDoctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(removeDocBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addDocBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(docsBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        panelDoctorLayout.setVerticalGroup(
            panelDoctorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDoctorLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel4)
                .addGap(15, 15, 15)
                .addComponent(docsBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(addDocBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(removeDocBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Menu Enfermeras");

        nursBtn.setBackground(new java.awt.Color(51, 153, 255));
        nursBtn.setForeground(new java.awt.Color(255, 255, 255));
        nursBtn.setText("Ver Enfermer(a/o)s");
        nursBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nursBtnActionPerformed(evt);
            }
        });

        addNurBtn.setBackground(new java.awt.Color(0, 153, 0));
        addNurBtn.setForeground(new java.awt.Color(255, 255, 255));
        addNurBtn.setText("Agregar Enfermera");
        addNurBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addNurBtnActionPerformed(evt);
            }
        });

        removeNurBtn.setBackground(new java.awt.Color(255, 102, 102));
        removeNurBtn.setForeground(new java.awt.Color(255, 255, 255));
        removeNurBtn.setText("Borrar Enfermera");
        removeNurBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeNurBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelNurseLayout = new javax.swing.GroupLayout(panelNurse);
        panelNurse.setLayout(panelNurseLayout);
        panelNurseLayout.setHorizontalGroup(
            panelNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelNurseLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(panelNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(addNurBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                        .addComponent(nursBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(removeNurBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(30, 30, 30))
        );
        panelNurseLayout.setVerticalGroup(
            panelNurseLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelNurseLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addGap(15, 15, 15)
                .addComponent(nursBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(addNurBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(removeNurBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Menu Habitaciones");

        roomsBtn.setBackground(new java.awt.Color(51, 153, 255));
        roomsBtn.setForeground(new java.awt.Color(255, 255, 255));
        roomsBtn.setText("Ver Habitaciones");
        roomsBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                roomsBtnActionPerformed(evt);
            }
        });

        addRoomBtn.setBackground(new java.awt.Color(0, 153, 0));
        addRoomBtn.setForeground(new java.awt.Color(255, 255, 255));
        addRoomBtn.setText("Agregar Habitacion");
        addRoomBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addRoomBtnActionPerformed(evt);
            }
        });

        removeRoomBtn.setBackground(new java.awt.Color(255, 102, 102));
        removeRoomBtn.setForeground(new java.awt.Color(255, 255, 255));
        removeRoomBtn.setText("Borrar Habitacion");
        removeRoomBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeRoomBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelRoomLayout = new javax.swing.GroupLayout(panelRoom);
        panelRoom.setLayout(panelRoomLayout);
        panelRoomLayout.setHorizontalGroup(
            panelRoomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRoomLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(panelRoomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(addRoomBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                    .addComponent(roomsBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(removeRoomBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30))
        );
        panelRoomLayout.setVerticalGroup(
            panelRoomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRoomLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel5)
                .addGap(15, 15, 15)
                .addComponent(roomsBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(addRoomBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(removeRoomBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Menu Servicios");

        servBtn.setBackground(new java.awt.Color(51, 153, 255));
        servBtn.setForeground(new java.awt.Color(255, 255, 255));
        servBtn.setText("Ver Servicios");
        servBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                servBtnActionPerformed(evt);
            }
        });

        addServBtn.setBackground(new java.awt.Color(0, 153, 0));
        addServBtn.setForeground(new java.awt.Color(255, 255, 255));
        addServBtn.setText("Agregar Servicio");
        addServBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addServBtnActionPerformed(evt);
            }
        });

        removeServBtn.setBackground(new java.awt.Color(255, 102, 102));
        removeServBtn.setForeground(new java.awt.Color(255, 255, 255));
        removeServBtn.setText("Borrar Servicio");
        removeServBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeServBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelServiceLayout = new javax.swing.GroupLayout(panelService);
        panelService.setLayout(panelServiceLayout);
        panelServiceLayout.setHorizontalGroup(
            panelServiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelServiceLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(panelServiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(removeServBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addServBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(servBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE))
                .addGap(30, 30, 30))
        );
        panelServiceLayout.setVerticalGroup(
            panelServiceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelServiceLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel6)
                .addGap(15, 15, 15)
                .addComponent(servBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(addServBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(removeServBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Otros");

        nursBtn1.setBackground(new java.awt.Color(51, 153, 255));
        nursBtn1.setForeground(new java.awt.Color(255, 255, 255));
        nursBtn1.setText("Ver Familiares");
        nursBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nursBtn1ActionPerformed(evt);
            }
        });

        invoiceBtn.setBackground(new java.awt.Color(51, 153, 255));
        invoiceBtn.setForeground(new java.awt.Color(255, 255, 255));
        invoiceBtn.setText("Ver Facturas");
        invoiceBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invoiceBtnActionPerformed(evt);
            }
        });

        historyInternshipBtn.setBackground(new java.awt.Color(51, 153, 255));
        historyInternshipBtn.setForeground(new java.awt.Color(255, 255, 255));
        historyInternshipBtn.setText("Historial Internados");
        historyInternshipBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                historyInternshipBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelConsultLayout = new javax.swing.GroupLayout(panelConsult);
        panelConsult.setLayout(panelConsultLayout);
        panelConsultLayout.setHorizontalGroup(
            panelConsultLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelConsultLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addGroup(panelConsultLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(nursBtn1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(invoiceBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(historyInternshipBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE))
                .addGap(30, 30, 30))
        );
        panelConsultLayout.setVerticalGroup(
            panelConsultLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelConsultLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel7)
                .addGap(15, 15, 15)
                .addComponent(nursBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(invoiceBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(historyInternshipBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Menu Consultas");

        consultBtn2.setBackground(new java.awt.Color(51, 153, 255));
        consultBtn2.setForeground(new java.awt.Color(255, 255, 255));
        consultBtn2.setText("Ver Consultas");
        consultBtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                consultBtnActionPerformed(evt);
            }
        });

        addConsultBtn4.setBackground(new java.awt.Color(0, 153, 0));
        addConsultBtn4.setForeground(new java.awt.Color(255, 255, 255));
        addConsultBtn4.setText("Agregar Consulta");
        addConsultBtn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addConsultBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelOthers2Layout = new javax.swing.GroupLayout(panelOthers2);
        panelOthers2.setLayout(panelOthers2Layout);
        panelOthers2Layout.setHorizontalGroup(
            panelOthers2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelOthers2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(panelOthers2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                    .addComponent(consultBtn2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addConsultBtn4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30))
        );
        panelOthers2Layout.setVerticalGroup(
            panelOthers2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelOthers2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel10)
                .addGap(15, 15, 15)
                .addComponent(consultBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(addConsultBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65))
        );

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Menu Internados");

        InternshipBtn.setBackground(new java.awt.Color(51, 153, 255));
        InternshipBtn.setForeground(new java.awt.Color(255, 255, 255));
        InternshipBtn.setText("Ver Pacientes Internados");
        InternshipBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InternshipBtnActionPerformed(evt);
            }
        });

        addInternshipBtn.setBackground(new java.awt.Color(0, 153, 0));
        addInternshipBtn.setForeground(new java.awt.Color(255, 255, 255));
        addInternshipBtn.setText("Agregar Internado");
        addInternshipBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addInternshipBtnActionPerformed(evt);
            }
        });

        removeInternshipBtn.setBackground(new java.awt.Color(255, 102, 102));
        removeInternshipBtn.setForeground(new java.awt.Color(255, 255, 255));
        removeInternshipBtn.setText("Eliminar Internado");
        removeInternshipBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeInternshipBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelOthers1Layout = new javax.swing.GroupLayout(panelOthers1);
        panelOthers1.setLayout(panelOthers1Layout);
        panelOthers1Layout.setHorizontalGroup(
            panelOthers1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelOthers1Layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addGroup(panelOthers1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
                    .addComponent(InternshipBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addInternshipBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(removeInternshipBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30))
        );
        panelOthers1Layout.setVerticalGroup(
            panelOthers1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelOthers1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel9)
                .addGap(15, 15, 15)
                .addComponent(InternshipBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(addInternshipBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(removeInternshipBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15))
        );

        javax.swing.GroupLayout containerLayout = new javax.swing.GroupLayout(container);
        container.setLayout(containerLayout);
        containerLayout.setHorizontalGroup(
            containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, containerLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(containerLayout.createSequentialGroup()
                        .addComponent(panelPatient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(panelDoctor, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(panelNurse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(panelConsult, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(containerLayout.createSequentialGroup()
                        .addComponent(panelRoom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(panelService, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(panelOthers1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(panelOthers2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(160, 160, 160))
        );
        containerLayout.setVerticalGroup(
            containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(containerLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelPatient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelNurse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelDoctor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelConsult, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(containerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelRoom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelService, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelOthers1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelOthers2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );

        exitBtn.setBackground(new java.awt.Color(255, 0, 0));
        exitBtn.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        exitBtn.setForeground(new java.awt.Color(255, 255, 255));
        exitBtn.setText("Salir");
        exitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(container, javax.swing.GroupLayout.PREFERRED_SIZE, 1020, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(20, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(167, 167, 167)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 682, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(container, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void exitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBtnActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitBtnActionPerformed

    private void addDocBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDocBtnActionPerformed
        this.dispose();
        new addDoctor().setVisible(true);
    }//GEN-LAST:event_addDocBtnActionPerformed

    private void addNurBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addNurBtnActionPerformed
        this.dispose();
        new addNurse().setVisible(true);
    }//GEN-LAST:event_addNurBtnActionPerformed

    private void addRoomBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addRoomBtnActionPerformed
        this.dispose();
        new addRoom().setVisible(true);
    }//GEN-LAST:event_addRoomBtnActionPerformed

    private void docsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_docsBtnActionPerformed
        try {
            this.dispose();
            new DoctorList().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo los doctores.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_docsBtnActionPerformed

    private void removeDocBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeDocBtnActionPerformed
        try {
            String id = JOptionPane.showInputDialog(null,
                    "Ingrese el ID del doctor que desea eliminar");
            dt.deleteDoctor(id);
            util.showMsg("Doctor eliminado.",
                    "Exito",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error eliminando el doctor.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_removeDocBtnActionPerformed

    private void removeNurBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeNurBtnActionPerformed
        try {
            String id = JOptionPane.showInputDialog(null,
                    "Ingrese el ID de la enfermera que desea eliminar");
            ns.deleteNurse(id);
            util.showMsg("Enfermera eliminada.",
                    "Exito",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error eliminando la enfermera.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_removeNurBtnActionPerformed

    private void nursBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nursBtnActionPerformed
        try {
            this.dispose();
            new NurseList().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo las enfermeras.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_nursBtnActionPerformed

    private void patBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_patBtnActionPerformed
        try {
            this.dispose();
            new PatientList().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo los pacientes.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_patBtnActionPerformed

    private void addPatBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addPatBtnActionPerformed
        this.dispose();
        new addPatient().setVisible(true);
    }//GEN-LAST:event_addPatBtnActionPerformed

    private void deletePatBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletePatBtnActionPerformed
        try {
            String id = JOptionPane.showInputDialog(null,
                    "Ingrese el ID del paciente que desea eliminar");
            pt.deletePatient(id);
            util.showMsg("Paciente eliminado.",
                    "Exito",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error eliminando al paciente.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_deletePatBtnActionPerformed

    private void servBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_servBtnActionPerformed
        try {
            this.dispose();
            new ServiceList().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo los servicios.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_servBtnActionPerformed

    private void addServBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addServBtnActionPerformed
        this.dispose();
        new addService().setVisible(true);
    }//GEN-LAST:event_addServBtnActionPerformed

    private void removeServBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeServBtnActionPerformed
        try {
            String id = JOptionPane.showInputDialog(null,
                    "Ingrese el ID del servicio que desea eliminar");
            rm.deleteRoom(id);
            util.showMsg("Servicio eliminado.",
                    "Exito",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error eliminando el servicio.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_removeServBtnActionPerformed

    private void nursBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nursBtn1ActionPerformed
        try {
            this.dispose();
            new FamiliarList().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo las habitaciones.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_nursBtn1ActionPerformed

    private void invoiceBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invoiceBtnActionPerformed
        try {
            this.dispose();
            new InvoiceList().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo los pacientes internados.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_invoiceBtnActionPerformed

    private void roomsBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_roomsBtnActionPerformed
        try {
            this.dispose();
            new RoomList().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo las habitaciones.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_roomsBtnActionPerformed

    private void removeRoomBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeRoomBtnActionPerformed
        try {
            String id = JOptionPane.showInputDialog(null,
                    "Ingrese el ID de la habitacion que desea eliminar");
            rm.deleteRoom(id);
            util.showMsg("Habitacion eliminada.",
                    "Exito",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error eliminando la habitacion.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_removeRoomBtnActionPerformed

    private void InternshipBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InternshipBtnActionPerformed
        try {
            this.dispose();
            new InternshipList().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo los internados.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_InternshipBtnActionPerformed

    private void addInternshipBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addInternshipBtnActionPerformed
        this.dispose();
        new addInternship().setVisible(true);
    }//GEN-LAST:event_addInternshipBtnActionPerformed

    private void removeInternshipBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeInternshipBtnActionPerformed
        try {
            String id = JOptionPane.showInputDialog(null,
                    "Ingrese el ID del internado que desea eliminar");
            is.deleteInternship(id);
            util.showMsg("Internado eliminada.",
                    "Exito",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error eliminando el internado.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_removeInternshipBtnActionPerformed

    private void addConsultBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addConsultBtnActionPerformed
        this.dispose();
        new addConsult().setVisible(true);
    }//GEN-LAST:event_addConsultBtnActionPerformed

    private void consultBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_consultBtnActionPerformed
        try {
            this.dispose();
            new ConsultList().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo las consultas.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_consultBtnActionPerformed

    private void historyInternshipBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_historyInternshipBtnActionPerformed
        try {
            this.dispose();
            new InternshipHistory().setVisible(true);
        } catch (SQLException ex) {
            util.showMsg("Ocurrio un error obteniendo las consultas.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_historyInternshipBtnActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton InternshipBtn;
    private javax.swing.JButton addConsultBtn;
    private javax.swing.JButton addConsultBtn4;
    private javax.swing.JButton addDocBtn;
    private javax.swing.JButton addInternshipBtn;
    private javax.swing.JButton addNurBtn;
    private javax.swing.JButton addPatBtn;
    private javax.swing.JButton addRoomBtn;
    private javax.swing.JButton addServBtn;
    private javax.swing.JButton consultBtn;
    private javax.swing.JButton consultBtn2;
    private javax.swing.JPanel container;
    private javax.swing.JButton deletePatBtn;
    private javax.swing.JButton docsBtn;
    private javax.swing.JButton exitBtn;
    private javax.swing.JButton historyInternshipBtn;
    private javax.swing.JButton invoiceBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton nursBtn;
    private javax.swing.JButton nursBtn1;
    private javax.swing.JPanel panelConsult;
    private javax.swing.JPanel panelDoctor;
    private javax.swing.JPanel panelNurse;
    private javax.swing.JPanel panelOthers;
    private javax.swing.JPanel panelOthers1;
    private javax.swing.JPanel panelOthers2;
    private javax.swing.JPanel panelPatient;
    private javax.swing.JPanel panelRoom;
    private javax.swing.JPanel panelService;
    private javax.swing.JButton patBtn;
    private javax.swing.JButton removeDocBtn;
    private javax.swing.JButton removeInternshipBtn;
    private javax.swing.JButton removeNurBtn;
    private javax.swing.JButton removeRoomBtn;
    private javax.swing.JButton removeServBtn;
    private javax.swing.JButton roomsBtn;
    private javax.swing.JButton servBtn;
    // End of variables declaration//GEN-END:variables
}
