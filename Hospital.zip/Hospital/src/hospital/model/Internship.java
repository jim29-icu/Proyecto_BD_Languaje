package hospital.model;

import hospital.Util;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public class Internship {

    private int idInternship;
    private String idPatient;
    private int idRoom;
    private Date checkIn;
    private Date checkOut;
    private final Util util = new Util();

    public Internship() {
    }

    public Internship(String idPatient, int idRoom) {
        this.idPatient = idPatient;
        this.idRoom = idRoom;
    }

    public int getIdInternship() {
        return idInternship;
    }

    public void setIdInternship(int idInternship) {
        this.idInternship = idInternship;
    }

    public String getIdPatient() {
        return idPatient;
    }

    public void setIdPatient(String idPatient) {
        this.idPatient = idPatient;
    }

    public int getIdRoom() {
        return idRoom;
    }

    public void setIdRoom(int idRoom) {
        this.idRoom = idRoom;
    }

    public Date getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(Date checkIn) {
        this.checkIn = checkIn;
    }

    public Date getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(Date checkOut) {
        this.checkOut = checkOut;
    }

    public ResultSet getInternshipHistory() throws SQLException {
        String sql = "{ ? = call pkg_internado.historial_internado() }";
        return util.executeCommandGetCursor(sql);
    }
    
    public ResultSet getInternship(String... search) throws SQLException {
        String sql = "";
        if (search.length == 0) {
            sql = "{ ? = call pkg_internado.listar_internados() }";
        } else {
            sql = "{ ? = call pkg_internado.buscar_internado('" + search[0] + "') }";
        }
        return util.executeCommandGetCursor(sql);
    }

    public void updateInternship(String id) throws SQLException {
        String sql = "BEGIN "
                + "pkg_internado.actualizar_internado("
                + "" + id + ");"
                + " END;";
        util.executeCommand(sql);
    }

    public void addInternship(Internship patient) throws SQLException {
        String sql = "BEGIN "
                + "pkg_internado.agregar_internado("
                + "'" + patient.idPatient + "', "
                + "" + patient.idRoom + ");"
                + " END;";
        util.executeCommand(sql);
    }

    public void deleteInternship(String idS) throws SQLException {
        int id = Integer.parseInt(idS);
        String sql = "BEGIN "
                + "pkg_internado.borrar_internado("
                + "" + id + ");"
                + "END;";
        util.executeCommand(sql);
    }
}
