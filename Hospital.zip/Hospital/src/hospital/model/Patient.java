package hospital.model;

import hospital.Util;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Patient {

    private String id;
    public String name;
    public String lastName;
    public Double weight;
    public String phone;
    private final Util util = new Util();

    public Patient() {
    }

    public Patient(String id, String name, String lastName, Double weight, String phone) {
        this.id = id;
        this.name = name;
        this.lastName = lastName;
        this.weight = weight;
        this.phone = phone;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public ResultSet getPatients(String... search) throws SQLException {
        String sql = "";
        if (search.length == 0) {
            sql = "{ ? = call pkg_paciente.listar_pacientes() }";
        } else {
            sql = "{ ? = call pkg_paciente.buscar_paciente('" + search[0] + "') }";
        }
        return util.executeCommandGetCursor(sql);
    }

    public void updatePatients(ArrayList<Patient> patients) throws SQLException {
        for (Patient patient : patients) {
            updatePatient(patient);
        }
    }

    private void updatePatient(Patient patient) throws SQLException {
        String sql = "BEGIN "
                + "pkg_paciente.actualizar_paciente("
                + "'" + patient.id + "', "
                + "'" + patient.name + "', "
                + "'" + patient.lastName + "', "
                + "" + patient.weight + ", "
                + "'" + patient.phone + "');"
                + " END;";
        util.executeCommand(sql);
    }

    public void addPatient(Patient patient) throws SQLException {
        String sql = "BEGIN "
                + "pkg_paciente.agregar_paciente("
                + "'" + patient.id + "', "
                + "'" + patient.name + "', "
                + "'" + patient.lastName + "', "
                + "" + patient.weight + ", "
                + "'" + patient.phone + "');"
                + " END;";
        util.executeCommand(sql);
    }

    public void deletePatient(String id) throws SQLException {
        String sql = "BEGIN "
                + "pkg_paciente.borrar_paciente("
                + "'" + id + "');"
                + "END;";
        util.executeCommand(sql);
    }
}
