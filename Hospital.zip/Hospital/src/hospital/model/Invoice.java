package hospital.model;

import hospital.Util;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Invoice {
    private int id;
    private int idConsult;
    private double taxes;
    private double total;
    private final Util util = new Util();

    public Invoice() {
    }

    public Invoice(int idConsult, double taxes, double total) {
        this.idConsult = idConsult;
        this.taxes = taxes;
        this.total = total;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdConsult() {
        return idConsult;
    }

    public void setIdConsult(int idConsult) {
        this.idConsult = idConsult;
    }

    public double getTaxes() {
        return taxes;
    }

    public void setTaxes(double taxes) {
        this.taxes = taxes;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    public void addInvoice(Invoice invoice) throws SQLException {
        String sql = "BEGIN "
                + "pkg_factura.agregar_factura("
                + "" + invoice.idConsult + ");"
                + " END;";
        util.executeCommand(sql);
    }
    
    public ResultSet getInvoices(String... search) throws SQLException{
        String sql = "";
        if (search.length == 0) {
            sql = "{ ? = call pkg_factura.listar_facturas() }";
        } else {
            sql = "{ ? = call pkg_factura.buscar_factura('" + search[0] + "') }";
        }
        return util.executeCommandGetCursor(sql);
    }
}