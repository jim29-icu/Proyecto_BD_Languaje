package hospital.model;

import hospital.Util;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Familiar {

    private String idFamiliar;
    private String name;
    private String lastName;
    private String phone;
    private String idPatient;
    private final Util util = new Util();

    public Familiar() {
    }

    public Familiar(String idFamiliar, String name, String lastName, String phone, String idPatient) {
        this.idFamiliar = idFamiliar;
        this.name = name;
        this.lastName = lastName;
        this.phone = phone;
        this.idPatient = idPatient;
    }

    public String getIdFamiliar() {
        return idFamiliar;
    }

    public void setIdFamiliar(String idFamiliar) {
        this.idFamiliar = idFamiliar;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdPatient() {
        return idPatient;
    }

    public void setIdPatient(String idPatient) {
        this.idPatient = idPatient;
    }

    public ResultSet getFamiliars(String... search) throws SQLException {
        String sql = "{ ? = call pkg_familiar.listar_familiares() }";
        return util.executeCommandGetCursor(sql);
    }

    public void addFamiliar(Familiar familiar) throws SQLException {
        String sql = "BEGIN "
                + "pkg_familiar.agregar_familiar("
                + "'" + familiar.idFamiliar + "', "
                + "'" + familiar.name + "', "
                + "'" + familiar.lastName + "', "
                + "" + familiar.phone + ", "
                + "'" + familiar.idPatient + "');"
                + " END;";
        util.executeCommand(sql);
    }
}
