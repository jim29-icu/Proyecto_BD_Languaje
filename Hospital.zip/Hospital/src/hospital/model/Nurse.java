package hospital.model;

import hospital.Util;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Nurse {

    private String idNurse;
    private String name;
    private String lastName;
    private final Util util = new Util();

    public Nurse() {
    }

    public Nurse(String idNurse, String name, String lastName) {
        this.idNurse = idNurse;
        this.name = name;
        this.lastName = lastName;
    }

    public String getIdNurse() {
        return idNurse;
    }

    public void setIdNurse(String idNurse) {
        this.idNurse = idNurse;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public ResultSet getNurses(String... search) throws SQLException {
        String sql = "";
        if (search.length == 0) {
            sql = "{ ? = call pkg_enfermera.listar_enfermeras() }";
        } else {
            sql = "{ ? = call pkg_enfermera.buscar_enfermera('" + search[0] + "') }";
        }
        return util.executeCommandGetCursor(sql);
    }

    public void updateNurse(ArrayList<Nurse> nurses) throws SQLException {
        for (Nurse nurse : nurses) {
            updateNurse(nurse);
        }
    }

    private void updateNurse(Nurse nurse) throws SQLException {
        String sql = "BEGIN "
                + "pkg_enfermera.actualizar_enfermera("
                + "'" + nurse.idNurse + "', "
                + "'" + nurse.name + "', "
                + "'" + nurse.lastName + "');"
                + " END;";
        util.executeCommand(sql);
    }

    public void addNurse(Nurse nurse) throws SQLException {
        String sql = "BEGIN "
                + "pkg_enfermera.agregar_enfermera("
                + "'" + nurse.idNurse + "', "
                + "'" + nurse.name + "', "
                + "'" + nurse.lastName + "');"
                + " END;";
        util.executeCommand(sql);
    }

    public void deleteNurse(String id) throws SQLException {
        String sql = "BEGIN "
                + "pkg_enfermera.borrar_enfermera("
                + "'" + id + "');"
                + "END;";
        util.executeCommand(sql);
    }
}
