package hospital.model;

import hospital.Util;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Room {
    private int idRoom;
    private String idNurse;
    private String typeRoom;
    private int busy;
    private final Util util = new Util();

    public Room() {
    }

    public Room(String idNurse, String typeRoom, int busy) {
        this.idNurse = idNurse;
        this.typeRoom = typeRoom;
        this.busy = busy;
    }

    public Room(int idRoom, String idNurse, String typeRoom, int busy) {
        this.idRoom = idRoom;
        this.idNurse = idNurse;
        this.typeRoom = typeRoom;
        this.busy = busy;
    }

    public int getIdRoom() {
        return idRoom;
    }

    public void setIdRoom(int idRoom) {
        this.idRoom = idRoom;
    }

    public String getIdNurse() {
        return idNurse;
    }

    public void setIdNurse(String idNurse) {
        this.idNurse = idNurse;
    }

    public String getTypeRoom() {
        return typeRoom;
    }

    public void setTypeRoom(String typeRoom) {
        this.typeRoom = typeRoom;
    }

    public int getBusy() {
        return busy;
    }

    public void setBusy(int busy) {
        this.busy = busy;
    }
    
    public ResultSet getRooms(String... search) throws SQLException{
        String sql = "";
        if (search.length == 0) {
            sql = "{ ? = call pkg_habitacion.listar_habitaciones() }";
        } else {
            sql = "{ ? = call pkg_habitacion.buscar_habitacion('" + search[0] + "') }";
        }
        return util.executeCommandGetCursor(sql);
    }

    public void updateRooms(ArrayList<Room> rooms) throws SQLException {
        for (Room room : rooms) {
            updateRoom(room);
        }
    }

    private void updateRoom(Room room) throws SQLException {
        String sql = "BEGIN "
                + "pkg_habitacion.actualizar_habitacion("
                + "" + room.idRoom + ", "
                + "'" + room.idNurse + "', "
                + "'" + room.typeRoom + "', "
                + "" + room.busy + ");"
                + " END;";
        util.executeCommand(sql);
    }

    public void addRoom(Room room) throws SQLException {
        String sql = "BEGIN "
                + "pkg_habitacion.agregar_habitacion("
                + "'" + room.idNurse + "', "
                + "'" + room.typeRoom + "', "
                + "" + 0 + ");"
                + " END;";
        util.executeCommand(sql);
    }

    public void deleteRoom(String idS) throws SQLException {
        int id = Integer.parseInt(idS);
        String sql = "BEGIN "
                + "pkg_habitacion.borrar_habitacion("
                + "" + id + ");"
                + "END;";
        util.executeCommand(sql);
    }
}
