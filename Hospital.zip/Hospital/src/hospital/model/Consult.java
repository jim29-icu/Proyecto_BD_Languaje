package hospital.model;

import hospital.Util;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

public class Consult {

    private String idConsult;
    private String idPatient;
    private String idDoctor;
    private int idService;
    private Date dateConsult;
    private String valoration;
    private String pressionPatient;
    private final Util util = new Util();

    public Consult() {
    }

    public Consult(String idPatient, String idDoctor, int idService) {
        this.idPatient = idPatient;
        this.idDoctor = idDoctor;
        this.idService = idService;
    }

    public String getIdConsult() {
        return idConsult;
    }

    public void setIdConsult(String idConsult) {
        this.idConsult = idConsult;
    }

    public String getIdPatient() {
        return idPatient;
    }

    public void setIdPatient(String idPatient) {
        this.idPatient = idPatient;
    }

    public String getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(String idDoctor) {
        this.idDoctor = idDoctor;
    }

    public int getIdService() {
        return idService;
    }

    public void setIdService(int idService) {
        this.idService = idService;
    }

    public Date getDateConsult() {
        return dateConsult;
    }

    public void setDateConsult(Date dateConsult) {
        this.dateConsult = dateConsult;
    }

    public String getValoration() {
        return valoration;
    }

    public void setValoration(String valoration) {
        this.valoration = valoration;
    }

    public String getPressionPatient() {
        return pressionPatient;
    }

    public void setPressionPatient(String pressionPatient) {
        this.pressionPatient = pressionPatient;
    }

    public void addConsult(Consult consult) throws SQLException {
        String sql = "BEGIN "
                + "pkg_consulta.agregar_consulta("
                + "'" + consult.idPatient + "', "
                + "'" + consult.idDoctor + "', "
                + "" + consult.idService + ");"
                + " END;";
        util.executeCommand(sql);
    }

    public ResultSet getConsults(String... search) throws SQLException {
        String sql = "";
        if (search.length == 0) {
            sql = "{ ? = call pkg_consulta.listar_consultas() }";
        } else {
            sql = "{ ? = call pkg_consulta.buscar_consulta('" + search[0] + "') }";
        }
        return util.executeCommandGetCursor(sql);
    }

    public ResultSet getConsultsByUser(String idPatient) throws SQLException {
        String sql = "{ ? = call pkg_consulta.buscar_consulta_usuario('" + idPatient + "') }";
        return util.executeCommandGetCursor(sql);
    }

    public void endConsult(String idS, String valoration) throws SQLException {
        int id = Integer.parseInt(idS);
        String sql = "BEGIN "
                + "pkg_consulta.terminar_consulta("
                + "" + id + ","
                + "'" + valoration + "');"
                + " END;";
        util.executeCommand(sql);
    }
}
