package hospital.model;

import hospital.Util;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Doctor {

    private String idDoctor;
    private String name;
    private String lastName;
    private String specialty;
    private int busy;
    private final Util util = new Util();

    public Doctor() {
    }

    public Doctor(String idDoctor, String name, String lastName, String specialty, int busy) {
        this.idDoctor = idDoctor;
        this.name = name;
        this.lastName = lastName;
        this.specialty = specialty;
        this.busy = busy;
    }

    public String getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(String idDoctor) {
        this.idDoctor = idDoctor;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public int isBusy() {
        return busy;
    }

    public void setBusy(int busy) {
        this.busy = busy;
    }

    public void updateDoctor(ArrayList<Doctor> doctors) throws SQLException {
        for (Doctor doctor : doctors) {
            updateDoctor(doctor);
        }
    }

    public ResultSet getDoctors(String... search) throws SQLException{
        String sql = "";
        if (search.length == 0) {
            sql = "{ ? = call pkg_doctor.listar_doctores() }";
        } else {
            sql = "{ ? = call pkg_doctor.buscar_doctor('" + search[0] + "') }";
        }
        return util.executeCommandGetCursor(sql);
    }
    
    private void updateDoctor(Doctor doctor) throws SQLException {
        String sql = "BEGIN "
                + "pkg_doctor.actualizar_doctor("
                + "'" + doctor.idDoctor + "', "
                + "'" + doctor.name + "', "
                + "'" + doctor.lastName + "', "
                + "'" + doctor.specialty + "', "
                + "" + doctor.busy + ");"
                + " END;";
        util.executeCommand(sql);
    }

    public void addDoctor(Doctor doctor) throws SQLException {
        String sql = "BEGIN "
                + "pkg_doctor.agregar_doctor("
                + "'" + doctor.idDoctor + "', "
                + "'" + doctor.name + "', "
                + "'" + doctor.lastName + "', "
                + "'" + doctor.specialty + "', "
                + "" + doctor.busy + ");"
                + " END;";
        util.executeCommand(sql);
    }

    public void deleteDoctor(String id) throws SQLException {
        String sql = "BEGIN "
                + "pkg_doctor.borrar_doctor("
                + "'" + id + "');"
                + "END;";
        util.executeCommand(sql);
    }
}
