package hospital.model;

import hospital.Util;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Service {
    private int idService;
    private String name;
    private Double price;
    private final Util util = new Util();

    public Service() {
    }

    public Service(int idService, String name, Double price) {
        this.idService = idService;
        this.name = name;
        this.price = price;
    }

    public Service(String name, Double price) {
        this.name = name;
        this.price = price;
    }

    public int getIdService() {
        return idService;
    }

    public void setIdService(int idService) {
        this.idService = idService;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }
    
    public ResultSet getServices(String... search) throws SQLException{
        String sql = "";
        if (search.length == 0) {
            sql = "{ ? = call pkg_servicio.listar_servicios() }";
        } else {
            sql = "{ ? = call pkg_servicio.buscar_servicio('" + search[0] + "') }";
        }
        return util.executeCommandGetCursor(sql);
    }

    public void updateServices(ArrayList<Service> Services) throws SQLException {
        for (Service service : Services) {
            updateService(service);
        }
    }

    private void updateService(Service service) throws SQLException {
        String sql = "BEGIN "
                + "pkg_servicio.actualizar_servicio("
                + "" + service.idService + ", "
                + "'" + service.name + "', "
                + "" + service.price + ");"
                + " END;";
        util.executeCommand(sql);
    }

    public void addService(Service service) throws SQLException {
        String sql = "BEGIN "
                + "pkg_servicio.agregar_servicio("
                + "'" + service.name + "', "
                + "" + service.price + ");"
                + " END;";
        util.executeCommand(sql);
    }

    public void deleteService(String idS) throws SQLException {
        int id = Integer.parseInt(idS);
        String sql = "BEGIN "
                + "pkg_servicio.borrar_servicio("
                + "" + id + ");"
                + "END;";
        util.executeCommand(sql);
    }
}
