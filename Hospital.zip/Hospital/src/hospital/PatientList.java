package hospital;

import hospital.model.Patient;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class PatientList extends javax.swing.JFrame {

    private static final Util util = new Util();
    private final Patient pt = new Patient();

    public PatientList() throws SQLException {
        initComponents();
        patTable.setModel(buildTable());
    }

    private DefaultTableModel buildTable(String... search) throws SQLException {
        ResultSet rs = pt.getPatients(search);
        ResultSetMetaData metaData = rs.getMetaData();

        // nombres de las columnas
        String[] names = {"ID", "Nombre", "Apellidos", "Peso (kg)", "Telefono"};
        Vector<String> columnNames = new Vector<>();
        int columnCount = metaData.getColumnCount();
        columnNames.addAll(Arrays.asList(names));

        // datos
        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }

        return new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return col != 0;
            }
        };

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        patTable = new javax.swing.JTable();
        updateBtn = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        searchTXT = new javax.swing.JTextField();
        searchBtn = new javax.swing.JButton();
        addFamBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        patTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellidos", "Residencia", "Telefono"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return columnIndex > 0;
            }
        });
        patTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(patTable);

        updateBtn.setBackground(new java.awt.Color(255, 204, 102));
        updateBtn.setText("Actualizar");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        jButton2.setText("Volver");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        searchBtn.setBackground(new java.awt.Color(102, 153, 255));
        searchBtn.setText("Buscar");
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });

        addFamBtn.setText("Agregar familiar");
        addFamBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addFamBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 710, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(searchTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(searchBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addFamBtn)
                        .addGap(18, 18, 18)
                        .addComponent(updateBtn)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(10, 10, 10))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateBtn)
                    .addComponent(jButton2)
                    .addComponent(searchTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBtn)
                    .addComponent(addFamBtn))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
        new Menu().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        ArrayList<Patient> patients = new ArrayList<>();
        for (int count = 0; count < patTable.getRowCount(); count++) {
            try {
                String id = patTable.getValueAt(count, 0).toString();
                String name = patTable.getValueAt(count, 1).toString();
                String lastName = patTable.getValueAt(count, 2).toString();
                Double weight = Double.valueOf(patTable.getValueAt(count, 3).toString());
                String phone = patTable.getValueAt(count, 4).toString();
                Patient patient = new Patient(id, name, lastName, weight, phone);
                patients.add(patient);
                pt.updatePatients(patients);
                util.showMsg("Pacientes actualizados.",
                        "Exito",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
                util.showMsg("Ocurrio un error actualizando los pacientes.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                System.out.println(ex);
            }
        }
    }//GEN-LAST:event_updateBtnActionPerformed

    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        try {
            String search = searchTXT.getText();
            if (search.isBlank()) {
                patTable.setModel(buildTable());
            } else {
                patTable.setModel(buildTable(search));
            }
        } catch (SQLException ex) {
            util.showMsg("Usuario no existe.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_searchBtnActionPerformed

    private void addFamBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addFamBtnActionPerformed
        int row = patTable.getSelectedRow();
        String idPat = patTable.getValueAt(row, 0).toString();
        this.dispose();
        new addFamiliar(idPat).setVisible(true);
    }//GEN-LAST:event_addFamBtnActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new PatientList().setVisible(true);
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addFamBtn;
    private javax.swing.JButton jButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable patTable;
    private javax.swing.JButton searchBtn;
    private javax.swing.JTextField searchTXT;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
