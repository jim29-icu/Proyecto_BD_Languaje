package hospital;

import hospital.model.Room;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class RoomList extends javax.swing.JFrame {

    private static final Util util = new Util();
    private final Room rm = new Room();

    public RoomList() throws SQLException {
        initComponents();
        rooTable.setModel(buildTable());
    }

    private DefaultTableModel buildTable(String... search) throws SQLException {
        ResultSet rs = rm.getRooms(search);
        ResultSetMetaData metaData = rs.getMetaData();

        // nombres de las columnas
        String[] names = {"ID", "ID Enfermera", "Enfermera", "Tipo", "Ocupada"};
        Vector<String> columnNames = new Vector<>();
        int columnCount = metaData.getColumnCount();
        columnNames.addAll(Arrays.asList(names));

        // datos
        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                if (columnIndex == columnCount) {
                    if (rs.getObject(columnIndex).toString().equals("1")) {
                        vector.add("Si");
                    } else if (rs.getObject(columnIndex).toString().equals("0")) {
                        vector.add("No");
                    }
                } else {
                    vector.add(rs.getObject(columnIndex));
                }
            }
            data.add(vector);
        }

        return new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return col != 0 && col != 2;
            }
        };

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        rooTable = new javax.swing.JTable();
        updateBtn = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        searchTXT = new javax.swing.JTextField();
        searchBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        rooTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellidos", "Residencia", "Telefono"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return columnIndex > 0;
            }
        });
        rooTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(rooTable);

        updateBtn.setBackground(new java.awt.Color(255, 204, 102));
        updateBtn.setText("Actualizar");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        jButton2.setText("Volver");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        searchBtn.setBackground(new java.awt.Color(102, 153, 255));
        searchBtn.setText("Buscar");
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 710, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(searchTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(searchBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(updateBtn)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(10, 10, 10))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateBtn)
                    .addComponent(jButton2)
                    .addComponent(searchTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBtn))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.dispose();
        new Menu().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        ArrayList<Room> rooms = new ArrayList<>();
        for (int count = 0; count < rooTable.getRowCount(); count++) {
            try {
                int id = Integer.parseInt(rooTable.getValueAt(count, 0).toString());
                String idNurse = rooTable.getValueAt(count, 1).toString();
                String type = rooTable.getValueAt(count, 3).toString();
                String busyString = rooTable.getValueAt(count, 4).toString();
                int busy = busyString.equalsIgnoreCase("si") ? 1 : 0;
                Room patient = new Room(id, idNurse, type, busy);
                rooms.add(patient);
                rm.updateRooms(rooms);
                util.showMsg("Habitaciones actualizadas.",
                        "Exito",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
                util.showMsg("Ocurrio un error actualizando las habitaciones.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                System.out.println(ex);
            }
        }
    }//GEN-LAST:event_updateBtnActionPerformed

    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        try {
            String search = searchTXT.getText();
            if (search.isBlank()) {
                rooTable.setModel(buildTable());
            } else {
                rooTable.setModel(buildTable(search));
            }
        } catch (SQLException ex) {
            util.showMsg("Usuario no existe.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            System.out.println(ex);
        }
    }//GEN-LAST:event_searchBtnActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new RoomList().setVisible(true);
                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable rooTable;
    private javax.swing.JButton searchBtn;
    private javax.swing.JTextField searchTXT;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
