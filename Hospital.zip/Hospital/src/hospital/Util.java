package hospital;

import java.sql.*;
import javax.swing.JOptionPane;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

public class Util {

    public static Connection connection;

    /**
     * Establece la conexion con la base de datos
     *
     * @param username String
     * @param password String
     * @return boolean
     */
    public boolean createConnection(String username, String password) {
        String url = "jdbc:oracle:thin:@//localhost:1521/oracle";
        try {
            Connection conn = DriverManager
                    .getConnection(url, username, password);
            connection = conn != null ? conn : null;
            return connection != null;
        } catch (SQLException ex) {
            System.out.println(ex);
            return false;
        }
    }

    /**
     * Retorna la conexion con la base de datos.
     *
     * @return Connection
     */
    public Connection getConnection() {
        return connection;
    }

    /**
     * Muestra mensajes al usuario
     *
     * @param msg String
     * @param title String
     * @param type int
     */
    public void showMsg(String msg, String title, int type) {
        JOptionPane.showMessageDialog(null,
                msg,
                title,
                type
        );
    }

    /**
     * Retorna el resultado al ejecutar el script de sql.
     *
     * @param sql String
     * @return ResultSet
     * @throws SQLException
     */
    public ResultSet executeCommand(String sql) throws SQLException {
        PreparedStatement preStatement = connection.prepareStatement(sql);
        return preStatement.executeQuery();
    }

    /**
     * Retorna el cursor al ejecutar el script de sql.
     *
     * @param sql String
     * @return ResultSet
     * @throws SQLException
     */
    public ResultSet executeCommandGetCursor(String sql) throws SQLException {
        CallableStatement stmt = connection.prepareCall(sql);
        stmt.registerOutParameter(1, OracleTypes.CURSOR);
        stmt.execute();
        return ((OracleCallableStatement)stmt).getCursor(1);
    }
}
