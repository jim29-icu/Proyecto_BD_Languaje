package hospital;

import java.sql.*;

public class Main {

    private static Util util = new Util();

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Login login = new Login();
        login.setVisible(true);
    }
}
